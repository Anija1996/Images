# ATELIER — React Ecommerce

This is the fresh React conversion of the ATELIER site.

## Included requirements

- React + Vite
- React Router routes
- Reusable Navbar, Footer, ProductCard, ProductGrid, CartItem and CategoryFilter
- Context API cart
- Axios product-data fetching
- Product detail route `/products/:id`
- Shop/category/search filtering
- Live cart item count in navigation
- Live contact-message character count
- Local account creation/sign-in using localStorage
- Wishlist page
- Delivery and order-confirmation flow
- Responsive desktop/mobile layouts
- Original ATELIER typography, colors, spacing and major homepage specifications
- Static hero image — no hero carousel
- Original repository image assets referenced from the `feature/img` GitHub branch

## Run

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

The image URLs currently point to the public `feature/img` branch of the supplied GitHub repository so the project can run without moving the image files first. For a fully self-contained deployment, copy the repository `assets` folder into `public/assets` and replace the image base URLs with `/assets/`.
